MA3105 OPERATING SYSTEMS LAB EXAM - xv6-public x86
=================================================

Student name: ______________________________
Roll number: _______________________________
Set: 1

This package implements the two questions in the supplied MA3105 exam sheet.
It is based on classic 32-bit xv6-public (x86), not xv6-riscv.

Q1 - Counting semaphores
------------------------
Files: sem.c, main.c, defs.h, syscall.h, syscall.c, sysproc.c, user.h,
usys.S, Makefile, synctest.c.

The kernel maintains eight semaphore slots (IDs 0..7). Each slot has a value
and in-use flag. The table is protected by semtab_lock, initialized by
seminit() during kernel startup. sem_wait() checks the value in a loop and
uses sleep(chan, &semtab_lock), so the lock is atomically released while the
process sleeps and reacquired before it rechecks the condition. sem_post()
increments under the same lock and calls wakeup() on the semaphore channel.
The test initializes semaphores 0,1,2 to 1,0,0 and chains three children: A
posts B, B posts C, and C posts A. This yields ABC repeated five times.

Q2 - Free page count and VA-to-PA translation
---------------------------------------------
Files: kalloc.c, vm.c, defs.h, syscall.h, syscall.c, sysproc.c, user.h,
usys.S, Makefile, memtest.c.

The allocator tracks free_pages under kmem.lock when locking is enabled.
kalloc() decrements it after removing a page; kfree() increments it after
returning a page. The count is initialized before kinit1() populates the
free list. The freepages() system call returns a protected snapshot.
The uva2pa() helper walks the current process page table, requires a present
PTE with PTE_U, and combines PTE_ADDR(*pte) with the page offset. va2pa()
returns -1 for invalid, absent, or non-user mappings. memtest.c checks the
free-page count, a global's mapping, an invalid address, and parent/child
physical addresses after fork. It then verifies pages are reclaimed after
wait().

System call numbers
-------------------
22 sem_init, 23 sem_wait, 24 sem_post, 25 freepages, 26 va2pa.
These numbers follow the unmodified xv6-public syscall table (1..21).

Build and run (Ubuntu)
---------------------
1. Extract the ZIP.
2. cd xv6-public
3. make clean
4. make qemu-nox CPUS=1
   (If your toolchain requires an empty prefix: make TOOLPREFIX= qemu-nox CPUS=1)
5. At the xv6 shell run: echo YOUR_ROLL_NUMBER
6. Run: synctest
7. Run: memtest
8. Leave QEMU with Ctrl-a, then x.

The classic xv6 Makefile can require -Wno-error=array-bounds with newer GCC;
that compatibility flag is included without disabling -Werror generally.

Expected checks
---------------
Q1 prints exactly ABCABCABCABCABC and then Done.
Q2: after sbrk(), free pages should decrease. va2pa(0x7fffffff) should print
-1. Parent and child should print the same global VA but different PAs.
After the child exits and is reaped, freepages() should return to its
pre-fork value, absent unrelated allocator activity.

Before submission
------------------
- Run both tests in your own QEMU session.
- Capture genuine screenshots/logs named Q1_output and Q2_output. Ensure your
  roll number is visible by running echo YOUR_ROLL_NUMBER before each test.
- Fill in your name and roll number above.
- Run make clean before archiving the complete xv6 directory.

No fabricated QEMU screenshots or runtime logs are included.
