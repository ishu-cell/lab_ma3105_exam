// MA3105 Q1: enforce A-B-C ordering using only kernel semaphores.
#include "types.h"
#include "user.h"

static void
run_letter(int wait_id, int post_id, char letter)
{
  int i;
  for(i = 0; i < 5; i++){
    if(sem_wait(wait_id) < 0){
      printf(1, "sem_wait failed for %c\n", letter);
      exit();
    }
    printf(1, "%c", letter);
    if(sem_post(post_id) < 0){
      printf(1, "sem_post failed for %c\n", letter);
      exit();
    }
  }
  exit();
}

int
main(void)
{
  int pid;

  if(sem_init(0, 1) < 0 || sem_init(1, 0) < 0 || sem_init(2, 0) < 0){
    printf(1, "semaphore initialization failed\n");
    exit();
  }

  // Child A starts the chain: A posts B, B posts C, C posts A.
  pid = fork();
  if(pid < 0){ printf(1, "fork A failed\n"); exit(); }
  if(pid == 0) run_letter(0, 1, 'A');

  pid = fork();
  if(pid < 0){ printf(1, "fork B failed\n"); exit(); }
  if(pid == 0) run_letter(1, 2, 'B');

  pid = fork();
  if(pid < 0){ printf(1, "fork C failed\n"); exit(); }
  if(pid == 0) run_letter(2, 0, 'C');

  wait();
  wait();
  wait();
  printf(1, "\nDone\n");
  exit();
}
