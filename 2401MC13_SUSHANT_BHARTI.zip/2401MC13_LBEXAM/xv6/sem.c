// MA3105 Q1: kernel counting semaphores for user processes.
#include "types.h"
#include "defs.h"
#include "param.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"

#define NSEMS 8

struct semaphore {
  int value;
  int inuse;
};

static struct semaphore semtab[NSEMS];
static struct spinlock semtab_lock;

// Called during kernel startup after pinit().
void
seminit(void)
{
  int i;
  initlock(&semtab_lock, "semaphores");
  for(i = 0; i < NSEMS; i++){
    semtab[i].value = 0;
    semtab[i].inuse = 0;
  }
}

int
sem_init(int id, int value)
{
  if(id < 0 || id >= NSEMS || value < 0)
    return -1;
  acquire(&semtab_lock);
  semtab[id].value = value;
  semtab[id].inuse = 1;
  release(&semtab_lock);
  return 0;
}

int
sem_wait(int id)
{
  if(id < 0 || id >= NSEMS)
    return -1;
  acquire(&semtab_lock);
  if(!semtab[id].inuse){
    release(&semtab_lock);
    return -1;
  }
  // Always re-check after wakeup: wakeup() does not reserve the semaphore.
  while(semtab[id].value == 0){
    if(myproc()->killed){
      release(&semtab_lock);
      return -1;
    }
    // sleep() atomically releases semtab_lock while sleeping and reacquires it.
    sleep(&semtab[id], &semtab_lock);
    if(!semtab[id].inuse){
      release(&semtab_lock);
      return -1;
    }
  }
  semtab[id].value--;
  release(&semtab_lock);
  return 0;
}

int
sem_post(int id)
{
  if(id < 0 || id >= NSEMS)
    return -1;
  acquire(&semtab_lock);
  if(!semtab[id].inuse){
    release(&semtab_lock);
    return -1;
  }
  semtab[id].value++;
  // Wake all sleepers; each waiter re-checks the value under this lock.
  wakeup(&semtab[id]);
  release(&semtab_lock);
  return 0;
}
