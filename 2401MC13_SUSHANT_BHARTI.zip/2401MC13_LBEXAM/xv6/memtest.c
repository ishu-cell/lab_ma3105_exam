// MA3105 Q2: inspect free pages and virtual-to-physical translation.
#include "types.h"
#include "user.h"

int global_value = 12345;

int
main(void)
{
  int start_free, after_sbrk, before_fork, after_fork, after_wait;
  int parent_pa, child_pa;
  int pid;
  char *mem;

  printf(1, "MA3105 Q2 memory statistics and address translation\n");
  start_free = freepages();
  printf(1, "Free pages at start: %d\n", start_free);

  mem = sbrk(10 * 4096);
  if(mem == (char*)-1){
    printf(1, "sbrk allocation failed\n");
    exit();
  }
  after_sbrk = freepages();
  printf(1, "Free pages after sbrk(10 * 4096): %d\n", after_sbrk);

  printf(1, "Global variable VA: 0x%x\n", (uint)&global_value);
  printf(1, "Global variable PA: 0x%x\n", va2pa((int)&global_value));
  printf(1, "va2pa(0x7fffffff): %d\n", va2pa(0x7fffffff));

  before_fork = freepages();
  printf(1, "Free pages immediately before fork: %d\n", before_fork);
  pid = fork();
  if(pid < 0){
    printf(1, "fork failed\n");
    exit();
  }
  if(pid == 0){
    child_pa = va2pa((int)&global_value);
    printf(1, "Child: pid=%d, global VA=0x%x, global PA=0x%x\n",
           getpid(), (uint)&global_value, child_pa);
    printf(1, "Child: free pages after fork: %d\n", freepages());
    exit();
  }

  parent_pa = va2pa((int)&global_value);
  after_fork = freepages();
  printf(1, "Parent: pid=%d, global VA=0x%x, global PA=0x%x\n",
         getpid(), (uint)&global_value, parent_pa);
  printf(1, "Parent: free pages after fork: %d\n", after_fork);
  wait();
  after_wait = freepages();
  printf(1, "Free pages after child exit and wait: %d\n", after_wait);
  printf(1, "Free pages before fork were: %d\n", before_fork);
  if(after_wait == before_fork)
    printf(1, "Child memory reclaimed: PASS\n");
  else
    printf(1, "Child memory reclaimed: check other allocator activity\n");

  // Release this test's own heap allocation too.
  if(sbrk(-10 * 4096) == (char*)-1)
    printf(1, "heap shrink failed\n");
  printf(1, "Free pages after releasing test allocation: %d\n", freepages());
  exit();
}
